
import React, { useState } from 'react';

function App() {
  const [game, setGame] = useState('mlbb');
  const [playerId, setPlayerId] = useState('');
  const [amount, setAmount] = useState('');

  const handleTopUp = async (e) => {
    e.preventDefault();

    const response = await fetch('/api/top-up', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ game, playerId, amount }),
    });

    const result = await response.json();
    alert(result.message);
  };

  const handlePayment = async (e) => {
    e.preventDefault();

    const response = await fetch('/api/top-up/create-checkout-session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount }),
    });

    const session = await response.json();
    const stripe = Stripe('your-publishable-key');
    stripe.redirectToCheckout({ sessionId: session.id });
  };

  return (
    <div className="App">
      <h1>Game Top-Up</h1>
      <form onSubmit={handlePayment}>
        <label htmlFor="game">Select Game:</label>
        <select id="game" value={game} onChange={(e) => setGame(e.target.value)}>
          <option value="mlbb">Mobile Legends: Bang Bang</option>
          <option value="codm">Call of Duty Mobile</option>
        </select>
        <label htmlFor="player-id">Player ID:</label>
        <input type="text" id="player-id" value={playerId} onChange={(e) => setPlayerId(e.target.value)} />
        <label htmlFor="amount">Amount:</label>
        <input type="number" id="amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <button type="submit">Top-Up</button>
      </form>
    </div>
  );
}

export default App;
