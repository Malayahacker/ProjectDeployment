
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const topupRoutes = require('./routes/topup');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use('/api/top-up', topupRoutes);

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
