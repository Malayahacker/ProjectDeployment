
const express = require('express');
const fetch = require('node-fetch');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

router.post('/', async (req, res) => {
  const { game, playerId, amount } = req.body;

  try {
    const response = await fetch('https://third-party-service.com/api/top-up', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.THIRD_PARTY_API_KEY}`,
      },
      body: JSON.stringify({ game, playerId, amount }),
    });

    const data = await response.json();

    if (data.success) {
      res.json({ message: 'Top-up successful!' });
    } else {
      res.json({ message: 'Top-up failed. Please try again.' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

router.post('/create-checkout-session', async (req, res) => {
  const { amount } = req.body;
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card', 'apple_pay', 'google_pay'],
    line_items: [{
      price_data: {
        currency: 'usd',
        product_data: {
          name: 'Game Top-Up',
        },
        unit_amount: amount * 100,
      },
      quantity: 1,
    }],
    mode: 'payment',
    success_url: 'https://your-website.com/success',
    cancel_url: 'https://your-website.com/cancel',
  });

  res.json({ id: session.id });
});

module.exports = router;
